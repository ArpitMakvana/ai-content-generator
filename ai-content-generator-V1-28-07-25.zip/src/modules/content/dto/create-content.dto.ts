import { IsOptional, IsString, IsBoolean, IsNotEmpty } from 'class-validator';

export class CreateContentDto {
  @IsString()
  @IsNotEmpty()
  topic: string;

  @IsOptional()
  @IsBoolean()
  requireImage?: boolean;

  @IsOptional()
  @IsBoolean()
  requireVideo?: boolean;

  @IsOptional()
  @IsString()
  format?: 'text' | 'html'; // output formatting preference
}