import { Injectable } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { of } from 'rxjs';

@Injectable()
export class AuthService {
  constructor(private http: HttpService) {
  }

  validateUser(token: string) {
    // Uncomment for real API call
    // return this.http.get('https://aismartlms.isplpos.com/api/validate-token', {
    //   headers: { Authorization: `Bearer ${token}` },
    // }).pipe(map(res => res.data));

    //  Mocked for now 
    return of({
      valid: true,
      userId: 'mock-user-id',
    });
  }
}
